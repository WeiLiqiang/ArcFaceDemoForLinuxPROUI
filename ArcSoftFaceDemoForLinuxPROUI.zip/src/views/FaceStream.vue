<template>
  <div class="multi-player">
    <div
      v-for="(playerItem, index) in players"
      :key="index"
      class="player-container"
    >
      <!-- 输入 + 播放按钮 -->
      <div class="input-row">
        <el-input
          v-model="playerItem.url"
          placeholder="请输入播放地址:例：E:\FFOutput\01.mp4；rtsp:xxxxx；http://xxx.mp4等"
          clearable
        />
        <el-button
          type="primary"
          @click="play(index)"
          style="margin-left: 10px;"
        >播放</el-button>
      </div>

      <!-- 播放区域 -->
      <div :id="'mse-' + index" class="player-box"></div>
    </div>
  </div>
</template>

<script setup>
import { reactive, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import FlvJsPlayer from 'xgplayer-flv'

// 四个播放器实例
const players = reactive([
  { url: '', instance: null },
  { url: '', instance: null },
  { url: '', instance: null },
  { url: '', instance: null },
])

// 播放函数
const play = (index) => {
  const playerItem = players[index]
  if (!playerItem.url) {
    ElMessage.error(`请输入第 ${index + 1} 路播放地址`)
    return
  }

  const containerId = 'mse-' + index
  const streamUrl = 'stream?address=' + encodeURIComponent(playerItem.url)

  // 销毁旧实例
  if (playerItem.instance) {
    playerItem.instance.destroy()
    playerItem.instance = null
  }

  // 创建新实例
  const player = new FlvJsPlayer({
    id: containerId,
    url: streamUrl,
    isLive: true,
    autoplay: true,
    playsinline: true,
    width: '100%',
    height: '100%',
  })

  // 监听错误事件
  player.on('error', (e) => {
    console.error(`第 ${index + 1} 路播放失败`, e)
    ElMessage.error(`第 ${index + 1} 路播放失败！`)
    player.destroy()
    playerItem.instance = null
  })

  playerItem.instance = player
}

// 页面卸载清理所有播放器
onUnmounted(() => {
  players.forEach(p => p.instance?.destroy())
})
</script>

<style scoped>
.multi-player {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
  align-items: flex-start;
  margin-top: 20px;
}

.player-container {
  width: 48%;
  display: flex;
  flex-direction: column;
}

.input-row {
  display: flex;
  margin-bottom: 10px;
}

/* 播放区域样式 */
.player-box {
  width: 100%;
  aspect-ratio: 16 / 9;
  border: 1px solid #ccc;
  background: #000;
  overflow: hidden;
  position: relative;
  border-radius: 8px;
}

/* 防止xgplayer层级覆盖 */
.player-box video {
  position: relative !important;
  z-index: 0 !important;
}

@media (max-width: 900px) {
  .player-container {
    width: 100%;
  }
}
</style>
